from django.shortcuts import render
from .model_diary import register
from .model_diary import login
from django.http import HttpResponse
import torch
from torch import nn
from torch.utils.data import Dataset
from torch import optim
import numpy as np
import gluonnlp as nlp
from tqdm import tqdm, tqdm_notebook
from transformers import AdamW
from transformers.optimization import get_cosine_schedule_with_warmup
from kobert import get_pytorch_kobert_model
from kobert.utils import get_tokenizer

#--------------------------------------


# Create your views here.

def main_logout(request):
    return render(
    request,
    'diaryapp/main_logout.html',
    {}
)

# txt list
def text(request):
    # return HttpResponse("hello")

    return render(
        request,
        "diaryapp/text.html",
        {}
    )
    
# voice list
def voice(request):

    return render(
        request,
        "diaryapp/voice.html",
        {}
    )

# diary list
def diary(request):

    return render(
        request,
        "diaryapp/diary.html",
        {}
    )
    
# txt 분석 결과페이지
def result_txt_login(request):
    # return HttpResponse("hello")
    return render(
        request,
        "diaryapp/result_txt.html",
        {}
    )

# nlp----------------------------------------

