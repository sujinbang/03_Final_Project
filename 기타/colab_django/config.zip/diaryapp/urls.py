from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from . import views


app_name='diaryapp'

urlpatterns = [
  path('',views.main_logout),
  path('text',views.text),
  path('voice',views.voice),
  path('diary',views.diary),
  path('result_t_login',views.result_txt_login),
  path('result_t_login/',views.koBert),
  
]