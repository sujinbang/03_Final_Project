from django.shortcuts import render
from .model_diary import register
from .model_diary import login
from django.http import HttpResponse
#--------------------------------------
from io import BytesIO
from base64 import b64decode
from google.colab import output
from IPython.display import Javascript
from IPython.display import display
from google.colab import output
from base64 import b64decode
from io import BytesIO
from pydub import AudioSegment
import speech_recognition as sr
from google.colab.output import eval_js

# Create your views here.

def main_logout(request):
    return render(
    request,
    'diaryapp/main_logout.html',
    {}
)

# txt list
def text(request):
    # return HttpResponse("hello")

    return render(
        request,
        "diaryapp/text.html",
        {}
    )
    
# voice list
def voice(request):

    return render(
        request,
        "diaryapp/voice.html",
        {}
    )

# diary list
def diary(request):

    return render(
        request,
        "diaryapp/diary.html",
        {}
    )

# 녹음함수 -------------------------------------------------------------

# def record(request):
    
#     text = []
    
#     dict = {'msg':text}

#     try :
#         while True :
#             r = sr.Recognizer()
            
#             with sr.Microphone() as source:                                          # 음성 입력
#                 print('음성을 입력하세요')
#                 audio = r.listen(source)
#                 try :
#                     print('음성변환 :'+ r.recognize_google(audio, language='ko-KR'))
#                     text.append(r.recognize_google(audio, language='ko-KR')) #한글로 변환
#                 except sr.UnknownValueError :                   # 오디오 불량 에러
#                     # print('오디오를 이해할 수 없습니다')
#                     # continue
#                     break
#                 except sr.RequestError as e :                   # 구글요청 에러
#                     print(f'에러가 발생하였습니다. 에러원인 : {e}')

#     except KeyboardInterrupt :
#         pass
    
#     return render(
#         request,
#         "diaryapp/voice.html",
#         dict
#     )


def record(request):

    RECORD = """
    const sleep  = time => new Promise(resolve => setTimeout(resolve, time))
    const b2text = blob => new Promise(resolve => {
      const reader = new FileReader()
      reader.onloadend = e => resolve(e.srcElement.result)
      reader.readAsDataURL(blob)
    })
    var record = time => new Promise(async resolve => {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      recorder = new MediaRecorder(stream)
      chunks = []
      recorder.ondataavailable = e => chunks.push(e.data)
      recorder.start()
      await sleep(time)
      recorder.onstop = async ()=>{
        blob = new Blob(chunks)
        text = await b2text(blob)
        resolve(text)
      }
      recorder.stop()
    })
    """


    sec = 20
    print("Speak Now...")
    display(Javascript(RECORD))
    sec += 1
    s = output.eval_js('record(%d)' % (sec*1000))
    # print("Done Recording !")
    b = b64decode(s.split(',')[1])
    audio = AudioSegment.from_file(BytesIO(b))
    a = audio.export('audio.wav',format='wav')
    #--------------------------------------------
    
    text = []

    dict = {'msg':text}

    try :
        while True :
            r = sr.Recognizer()
            
            with sr.AudioFile(a) as source:                                          # 음성 입력
                # print('음성을 입력하세요')
                audio_new = r.record(source)
                try :
                    print('음성변환 :'+ r.recognize_google(audio_new, language='ko-KR'))
                    text.append(r.recognize_google(audio_new, language='ko-KR')) #한글로 변환
                except sr.UnknownValueError :                   # 오디오 불량 에러
                    # print('오디오를 이해할 수 없습니다')
                    # continue
                    break
                except sr.RequestError as e :                   # 구글요청 에러
                    print(f'에러가 발생하였습니다. 에러원인 : {e}')

    except KeyboardInterrupt :
        pass

    return render(
        request,
        "diaryapp/voice.html",
        dict
  )

# 결과페이지 -------------------------------------------------------------
# txt 분석 결과
def result_txt_logout(request):
    # return HttpResponse("hello")
    if request.session.get("sMem_id"):
        context = """<script> 
                    location.href = '../result_t_login/'
                </script>"""
    else :
        context = """<script>
                    alert('직접 접근 하시면 안됩니다')
                    location.href = '../'
                </script>"""
                
    return HttpResponse(context)

# voice 분석 결과페이지
def result_txt_login(request):
    # return HttpResponse("hello")
    return render(
        request,
        "diaryapp/result_txt.html",
        {}
    )


# voice 분석 결과
def result_voice_logout(request):
    # return HttpResponse("hello")

    if request.session.get("sMem_id"):
        context = """<script> 
                    location.href = '../result_v_login/'
                </script>"""
    else :
        context = """<script>
                    alert('직접 접근 하시면 안됩니다')
                    location.href = '../'
                </script>"""
                
    return HttpResponse(context)

def result_voice_login(request):
    # return HttpResponse("hello")

    return render(
        request,
        "diaryapp/result_voice.html",
        {}
    )


#-----------------------------------------로그인 & 회원가입 -----------------------------------
## http://127.0.0.1:8000/libapp/insertTable/ << 테이블 먼저 만들기 
# 메인

# 회원가입 ---------------------------------------------------------------
# survey 테이블 생성하기
def createTable(request):
    register.createTableMember()
    
    return HttpResponse("Create OK.....")


# 회원가입 화면
def sign_up(request):
    return render(
        request,
        "diaryapp/signup.html",
        {}
    )

# 회원 데이터 입력
def set_Member_Insert(request):
    pmemid = request.POST.get("id")
    pmempass = request.POST.get("pass")
    pmempass_cf = request.POST.get("pass_cf")
    pmem_email = request.POST.get("email")
    
    pageControl = ""
    
    if pmemid == '' or pmempass =='' or pmempass_cf=='' or pmem_email=='':
        pageControl = """<script>
                    alert('정보를 입력해주세요')
                    location.href='../signup/'
                </script>
                """
        
    else  : 
        ms = register.setMemberInsert(pmemid, pmempass, pmempass_cf,pmem_email)
        
        if ms=='':
            pageControl = """<script>
                                alert('정보를 입력해주세요')
                                location.href='../signup/'
                            </script>
            """
        else: 
            
            # return HttpResponse("Insert OK")
            
            if ms == "OK" :
                pageControl = """<script>
                                    alert('회원가입 완료')
                                    location.href='../login/'
                                </script>
                """
            else:
                pageControl = """<script>
                                    alert('가입 실패!')
                                    history.go(-1)
                                </script>
                """
        
    return HttpResponse(pageControl)



# 로그인 파트 --------------------------------------------------------------- 
# 로그인 화면
def login_lib(request):
    return render(
        request,
        "diaryapp/login.html",
        {}
    )

def getlogin(request):
    try:
        pmem_id = request.POST["mem_id"]
        pmem_pass = request.POST["mem_pass"]
    
    except:
        context = """<script>
                        alert('직접 접근 하시면 안됩니다..로그인 페이지로 이동')
                        location.href = '../login/'
                    </script>"""
        return HttpResponse(context)
    
    # 아이디 패스워드 확인 모델 호출(한건 조회)
    df_dict = login.getLogin(pmem_id, pmem_pass)
    
    # 로그인 실패 시 처리
    if df_dict["ms"] == "no":
        context = """
        <script>
            alert('아이디 또는 패스워드를 확인하여 주세요!')
            history.go(-1)
        </script>
        """
        return HttpResponse(context)
    
    # Session 처리 (회원 정보를 서버에 저장해 놓고 있는 상태)
    #   - 로그아웃 하기 전까지 회원 정보는 어느 페이지를 가든 살아 있습니다.
    #   - request.session[]을 통해서 사용합니다
    #   - session에 저장되는 값들을 딕셔너리 형태로 저장됨
    
    # session 등록하기
    request.session["sMem_id"] = pmem_id
    # request.session["sMem_name"] = df_dict["mem_name"]
    
    # 세션에 저장된 값 불러오기
    if request.session.get("sMem_id"):
        # 세션에 값이 있는 경우
        df_dict["sMem_id"] = request.session["sMem_id"]
        # df_dict["sMem_name"] = request.session["sMem_name"]
    else :
        # 세션에 값이 없는 경우
        df_dict["sMem_id"] = None
        
    
    df_dict["pmem_id"] = pmem_id
    df_dict["pmem_pass"] = pmem_pass
    
    return render(
        request,
        "diaryapp/main_login.html",
        {}
    )
    
    # return render(
    #     request,
    #     "libapp/login.html",
    #     df_dict
    # )


# 로그아웃
def set_Logout(request):
    
    # 세션정보 확인하기
    if request.session.get("sMem_id"):
        # 세션정보 삭제하기
        request.session.flush()
        
        context = """<script>
                        alert('로그아웃 되었습니다.')
                        location.href = '../main_logout/'
                    </script>"""
    else :
        context = """<script>
                        alert('직접 접근 하시면 안됩니다')
                        location.href = '../main_logout/'
                    </script>"""
                    
    return HttpResponse(context)
